# Chat-System

## Aufgabe 8

### Features

- Anzeige und Versand von Nachrichten zwischen zwei Benutzern.
- Chatverlauf mit Timestamps.
- Einfache und intuitive Benutzeroberfläche.
- Nachrichten als gelesen markieren.
- Visuelle Anzeige für gelesene und ungelesene Nachrichten.

---

### Funktionsweise

#### Frontend (`index.php`)
- Zeigt den Chatverlauf in einer scrollbaren Ansicht an.
- Eingabeformular für neue Nachrichten mit einem Senden-Button.
- Dynamische Anpassung der Nachrichtendarstellung:
  - Links für den Absender, rechts für den Empfänger.
  - Gelesene Nachrichten werden mit einem grünen Häkchen angezeigt, ungelesene mit einem grauen Häkchen.

#### Backend-Logik
- **`MessageModel.php`**:
  - `getMessages()`: Ruft Nachrichten zwischen zwei Benutzern aus der Datenbank ab.
  - `sendMessage()`: Speichert eine neue Nachricht mit Zeitstempel.
  - `markMessageAsRead()`: Markiert eine Nachricht als gelesen.
- **`MessageController.php`**:
  - `index()`: Lädt die Chatansicht.
  - `sendMessage()`: Verarbeitet den Nachrichtenversand und leitet zurück zum Chat.
  - `markAsRead()`: Markiert eine Nachricht als gelesen und leitet zurück zum Chat.

---

### Ausgabe
![alt text](image-1.png)

