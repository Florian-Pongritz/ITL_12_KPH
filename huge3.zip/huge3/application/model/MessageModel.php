<?php

class MessageModel
{
    public static function getMessages($user_id, $receiver_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $stmt = $database->prepare("CALL GetMessages(:user_id, :receiver_id)");
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':receiver_id', $receiver_id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public static function sendMessage($sender_id, $receiver_id, $message)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $timestamp = time();
        $stmt = $database->prepare("CALL SendMessage(:sender_id, :receiver_id, :message, :timestamp)");
        $stmt->bindParam(':sender_id', $sender_id, PDO::PARAM_INT);
        $stmt->bindParam(':receiver_id', $receiver_id, PDO::PARAM_INT);
        $stmt->bindParam(':message', $message, PDO::PARAM_STR);
        $stmt->bindParam(':timestamp', $timestamp, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->rowCount() == 1;
    }

    public static function markMessageAsRead($message_id)
    {
        $database = DatabaseFactory::getFactory()->getConnection();

        $stmt = $database->prepare("CALL MarkMessageAsRead(:message_id)");
        $stmt->bindParam(':message_id', $message_id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->rowCount() == 1;
    }
}
