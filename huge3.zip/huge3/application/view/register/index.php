<div class="container">

    <!-- echo out the system feedback (error and success messages) -->
    <?php $this->renderFeedbackMessages(); ?>

    <!-- login box on left side -->
    <div class="login-box" style="width: 50%; display: block;">
        <h2>Register a new account</h2>

        <!-- register form -->
        <form method="post" action="<?php echo Config::get('URL'); ?>register/register_action" id="registrationForm">
            <!-- the user name input field uses a HTML5 pattern check -->
            <input type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" placeholder="Username (letters/numbers, 2-64 chars)" required />
            <input type="text" name="user_email" placeholder="email address (a real address)" required />
            <input type="text" name="user_email_repeat" placeholder="repeat email address (to prevent typos)" required />
            <input type="password" name="user_password_new" pattern=".{6,}" placeholder="Password (6+ characters)" required autocomplete="off" />
            <input type="password" name="user_password_repeat" pattern=".{6,}" required placeholder="Repeat your password" autocomplete="off" />
            
            <!-- reCAPTCHA token field -->
            <input type="hidden" name="recaptcha_token" id="recaptchaToken" />

            <input type="submit" value="Register" />
        </form>
    </div>
</div>

<!-- Add reCAPTCHA v3 script -->
<script src="https://www.google.com/recaptcha/api.js?render=6LdtMrgqAAAAAEAfrJYpszcNGLvOvj-WtkQUMjxh"></script>
<script>
    grecaptcha.ready(function() {
        grecaptcha.execute('6LdtMrgqAAAAAEAfrJYpszcNGLvOvj-WtkQUMjxh', {action: 'register'}).then(function(token) {
            document.getElementById('recaptchaToken').value = token;
        });
    });
</script>
