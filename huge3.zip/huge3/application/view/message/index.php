<div class="container">
    <h1>Messages with <?php echo htmlentities($this->receiver_name); ?></h1>
    <div class="discussion-scroll-container">
        <div class="discussion">
            <?php if ($this->messages) { ?>
                <?php foreach ($this->messages as $index => $message) { ?>
                    <div class="bubble <?php echo $message->sender_id == Session::get('user_id') ? 'recipient' : 'sender'; ?>
                    <?php echo $index == 0 ? 'first' : ''; ?> 
                    <?php echo $index == count($this->messages) - 1 ? 'last' : ''; ?>">
                        <p><?php echo htmlentities($message->message); ?></p>
                        <span><?php echo date('d.m.y H:i', $message->timestamp); ?></span>
                        <?php if ($message->read == 0 && $message->sender_id != Session::get('user_id')) { ?>
                            <?php MessageModel::markMessageAsRead($message->id); ?>
                        <?php } ?>
                        <?php if ($message->sender_id == Session::get('user_id')) { ?>
                            <span class="checkmark <?php echo $message->read == 1 ? 'read' : 'unread'; ?>">✔</span>
                        <?php } ?>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p>No messages yet.</p>
            <?php } ?>
        </div>
    </div>
    <div class="box">
        <form class="message-form" method="post" action="<?php echo Config::get('URL'); ?>message/sendMessage">
            <input type="hidden" name="receiver_id" value="<?php echo $this->receiver_id; ?>" />
            <textarea name="message" class="message-input" required></textarea>
            <button type="submit" class="send-message-button">Send</button>
        </form>
    </div>
</div>