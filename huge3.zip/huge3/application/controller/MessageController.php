<?php

class MessageController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        Auth::checkAuthentication();
    }

    public function index($receiver_id = null)
    {
        if ($receiver_id === null) {
            Redirect::to('dashboard/index');
            return;
        }

        $this->View->render('message/index', array(
            'messages' => MessageModel::getMessages(Session::get('user_id'), $receiver_id),
            'receiver_id' => $receiver_id,
            'receiver_name' => UserModel::getUserNameById($receiver_id)
        ));
    }

    public function sendMessage()
    {
        $sender_id = Session::get('user_id');
        $receiver_id = Request::post('receiver_id');
        $message = Request::post('message');
        MessageModel::sendMessage($sender_id, $receiver_id, $message);
        Redirect::to('message/index/' . $receiver_id);
    }

    public function markAsRead($message_id)
    {
        if (MessageModel::markMessageAsRead($message_id)) {
            Redirect::to('message/index');
        } else {
            Redirect::to('message/index');
        }
    }
}
